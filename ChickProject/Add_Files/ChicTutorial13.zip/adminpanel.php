<h1>Admin panel</h1>
<p><a href="admin.php?logout=true">Logout</a></p>
