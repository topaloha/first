<div class="seccontent">
    <table width="259" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="80" valign="top" class="textheading">WHERE:</td>
    <td width="179"><p>Merivale Mall</p>
    <p>Christchurch</p></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td valign="top" class="textheading">WHEN:</td>
    <td><p>M - F: 9am - 7pm</p>
    <p>Sat - Sun: 10am - 5pm</p></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
    </div><!--End of secondary content-->