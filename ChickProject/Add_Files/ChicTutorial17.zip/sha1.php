<?php
echo sha1("admin");
?>