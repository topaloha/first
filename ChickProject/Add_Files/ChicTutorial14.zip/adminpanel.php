<h1>Admin panel</h1>
<p><a href="admin.php?logout=true">Logout</a></p>
<p><a href="addcategory.php">Add new category</a></p>