<h1>Welcome to Chic Clothing</h1>
<p>This is our home page</p>