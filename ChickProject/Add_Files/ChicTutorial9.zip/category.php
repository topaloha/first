<?php
	// If categoryID is not set, redirect back to index page
	if(!isset($_GET['categoryID'])) {
		header("Location:index.php");
	}
	// Select all stock items belonging to the selected categoryID
	$stock_sql="SELECT stock.stockID, stock.name, stock.price, category.name AS catname FROM stock JOIN category ON stock.categoryID=category.categoryID WHERE stock.categoryID=".$_GET['categoryID'];
	if($stock_query=mysqli_query($dbconnect, $stock_sql)) {
		$stock_rs=mysqli_fetch_assoc($stock_query);
	}
	
	?>