<div class="header">
    	<div class="logo">
        <a href="index.php"><img src="images/logo.jpg" alt="Chic Clothing logo" /></a>
        </div><!--logo ends-->
		<div class="navigation">
		<p><?php 
			include("categoryList.php");
		?>
        <a href="index.php?page=admin">Admin</a>
        </p>
      </div><!--navigation ends-->
	</div><!-- Header ends here-->