<h1>Control panel</h1>
<p><a href="index.php?page=admin&action=logout">Logout</a></p>